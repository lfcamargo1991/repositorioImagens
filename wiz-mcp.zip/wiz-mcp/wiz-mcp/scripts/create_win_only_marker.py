#!/usr/bin/env python3
"""
Create .win-only marker file for local WIN-only mode testing.

This script creates a .win-only marker file in the project root to enable
auto-detection of WIN-only mode for local testing.
"""

import pathlib
import sys

# Get project root (go up from scripts/ to root)
script_dir = pathlib.Path(__file__).parent
project_root = script_dir.parent

marker_file = project_root / ".win-only"

if marker_file.exists():
    print(f".win-only marker file already exists at {marker_file}")
    sys.exit(0)

# Create the marker file
marker_file.touch()
print(f"Created .win-only marker file at {marker_file}")
print("WIN-only mode will now be auto-detected when running the server.")
