"""
Version information for the Wiz MCP Server.
"""

__version__ = "0.3.0"
