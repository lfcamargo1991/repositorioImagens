"""
Server module for the Wiz MCP Server.

This module provides the FastMCP server for the Wiz MCP Server, which enables
interaction with the Wiz cloud security platform through the Model Context Protocol.
The server exposes tools for retrieving and analyzing security issues and their
remediation strategies.
"""

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import List

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from wiz_mcp_server.auth.auth import authenticate
from wiz_mcp_server.utils.context import WizContext
from wiz_mcp_server.utils.logger import get_logger
from wiz_mcp_server.utils.user_agent import is_win_only_mode

# Global constants
SERVER_NAME = "Wiz MCP Server"
SERVER_DESCRIPTION = "A Model Context Protocol (MCP) server for the Wiz API"

logger = get_logger()


def get_env_var(var_name: str, default: str = None) -> str:
    """
    Get environment variable with WIN_ prefix support in WIN-only mode.

    In WIN-only mode, ONLY checks for WIN_ prefixed vars (no fallback to WIZ_).
    In full mode, uses WIZ_ prefixed vars.

    Args:
        var_name: Base variable name (e.g., "CLIENT_ID" becomes "WIN_CLIENT_ID" or "WIZ_CLIENT_ID")
        default: Default value if not found

    Returns:
        str: Environment variable value or default
    """
    # Use is_win_only_mode() to check marker file if env var not set yet
    is_win_only = is_win_only_mode()

    if is_win_only:
        # In WIN-only mode, ONLY use WIN_ prefix (no fallback to WIZ_)
        win_var = f"WIN_{var_name}"
        return os.environ.get(win_var) or default
    else:
        # In full mode, use WIZ_ prefix
        wiz_var = f"WIZ_{var_name}"
        return os.environ.get(wiz_var) or default


def validate_env(required_vars: List[str] = None) -> None:
    """Validate that required environment variables are set.

    Args:
        required_vars: List of environment variables that must be set

    Raises:
        ValueError: If any required environment variable is not set
    """
    if required_vars is None:
        # Use base names, get_env_var will handle WIN_/WIZ_ prefix
        required_vars = ["CLIENT_ID", "CLIENT_SECRET"]

    missing_vars = []
    # Use is_win_only_mode() to check marker file if env var not set yet
    is_win_only = is_win_only_mode()
    prefix = "WIN_" if is_win_only else "WIZ_"

    for var in required_vars:
        # Check if it's already a full var name (WIZ_/WIN_) or base name
        if var.startswith("WIZ_") or var.startswith("WIN_"):
            # Legacy format, check directly
            if not os.environ.get(var):
                missing_vars.append(var)
        else:
            # Base name, use get_env_var
            if not get_env_var(var):
                missing_vars.append(f"{prefix}{var}")

    if missing_vars:
        if len(missing_vars) == 1:
            raise ValueError(f"{missing_vars[0]} environment variable must be set")
        else:
            raise ValueError(f"The following environment variables must be set: {', '.join(missing_vars)}")


def load_environment(env_file_path=None):
    """Load environment variables from .env file."""
    # Check mode to determine which vars to look for
    # IMPORTANT: Check for WIN-only mode BEFORE loading env vars
    # This ensures we load WIN_ vars instead of WIZ_ vars when .win-only marker exists
    is_win_only = is_win_only_mode()

    # Debug logging to help identify why WIN-only mode is detected
    if is_win_only:
        mcp_mode_env = os.environ.get("WIZ_MCP_MODE")
        if mcp_mode_env:
            logger.debug(f"WIN-only mode detected via WIZ_MCP_MODE environment variable: {mcp_mode_env}")
        else:
            # Check which marker file was found
            import pathlib
            current_file = pathlib.Path(__file__).resolve()
            package_root = current_file.parent.parent.parent.parent
            marker_paths = [
                package_root / ".win-only",
                pathlib.Path(os.getcwd()) / ".win-only",
            ]
            if package_root.name in ('win-mcp', 'wiz-mcp'):
                marker_paths.append(package_root.parent / ".win-only")

            found_markers = [str(p) for p in marker_paths if p.exists()]
            if found_markers:
                logger.debug(f"WIN-only mode detected via .win-only marker file at: {', '.join(found_markers)}")
            else:
                logger.warning("WIN-only mode detected but no marker file found - this may indicate a bug")

    # Set WIZ_MCP_MODE env var if we detected WIN-only mode via marker file
    # This ensures other code can use the env var later
    if is_win_only and not os.environ.get("WIZ_MCP_MODE"):
        os.environ["WIZ_MCP_MODE"] = "win-only"
        logger.info("Auto-detected WIN-only mode (.win-only marker file found) - loading WIN_ environment variables")

    if is_win_only:
        # In WIN-only mode, ONLY check WIN_ vars (no WIZ_ vars)
        important_vars = ["WIN_CLIENT_ID", "WIN_CLIENT_SECRET", "WIN_ENV", "WIN_CONTENT_PATH"]
    else:
        important_vars = ["WIZ_CLIENT_ID", "WIZ_CLIENT_SECRET", "WIZ_ENV"]

    initial_vars = {var: os.environ.get(var) for var in important_vars}

    # Try loading from specified path, environment variable, current directory, or script directory
    if env_file_path:
        if os.path.exists(env_file_path):
            dotenv_path = os.path.abspath(env_file_path)
        else:
            logger.error(f"Specified .env file not found: {env_file_path}")
            raise FileNotFoundError(f"Specified .env file not found: {env_file_path}")
    else:
        # Check for WIZ_DOTENV_PATH environment variable
        env_path = os.environ.get("WIZ_DOTENV_PATH")
        if env_path and os.path.exists(env_path):
            dotenv_path = os.path.abspath(env_path)
            logger.info(f"Using .env file from WIZ_DOTENV_PATH environment variable: {dotenv_path}")
        else:
            cwd_path = os.path.join(os.getcwd(), ".env")
            script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")

            if os.path.exists(cwd_path):
                dotenv_path = cwd_path
            elif os.path.exists(script_path):
                dotenv_path = script_path
            else:
                logger.info("No .env file found")
                dotenv_path = None

    # Load the .env file if found
    if dotenv_path:
        logger.info(f"Loading environment variables from: {dotenv_path}")
        # Check if WIZ_MCP_MODE is in the .env file before loading
        env_mcp_mode_before = os.environ.get("WIZ_MCP_MODE")
        load_dotenv(dotenv_path)
        env_mcp_mode_after = os.environ.get("WIZ_MCP_MODE")
        if env_mcp_mode_before != env_mcp_mode_after:
            logger.info(f"WIZ_MCP_MODE was set from .env file: {env_mcp_mode_after}")

        # Log which variables were loaded
        loaded = [var for var in important_vars
                  if os.environ.get(var) and initial_vars[var] != os.environ.get(var)]
        if loaded:
            logger.info(f"Loaded variables: {', '.join(loaded)}")

    # Log the current environment value
    env_value = get_env_var("ENV", "app")
    logger.info(f"Using Wiz environment: {env_value}")


@asynccontextmanager
async def wiz_lifespan(mcp_server: FastMCP) -> AsyncIterator[WizContext]:
    """
    Manage application lifecycle with type-safe context.

    Args:
        mcp_server: FastMCP server

    Yields:
        WizContext: Wiz context

    Raises:
        ValueError: If required environment variables are not set
        Exception: If there's an error during authentication or tool registration
    """
    # Initialize on startup - authenticate with Wiz API
    try:
        # Validate required environment variables (use base names, get_env_var handles prefix)
        validate_env(["CLIENT_ID", "CLIENT_SECRET"])

        # Authenticate with Wiz API
        auth_result = await authenticate()

        # Fetch WIN API specs from remote source (if available)
        try:
            from wiz_mcp_server.tools.fetch_win_api_specs import fetch_win_api_specs
            fetch_win_api_specs()  # This will set WIZ_WIN_CONTENT_PATH if successful
        except Exception as e:
            logger.warning(f"Failed to fetch WIN API specs from remote: {e}")
            # Continue - WinApiSpecsLoader will use fallback/default path

        context = WizContext(
            auth_headers=auth_result.auth_headers,
            data_center=auth_result.data_center,
            env=auth_result.env
        )

        # Register tools based on mode
        try:
            from wiz_mcp_server.tools import (
                register_dynamic_tools,
                register_wiz_search_tool,
                register_win_apis_tool,
                register_issue_attack_path_structure_tool,
            )

            # Check if we're in WIN-only mode
            # Note: WIZ_MCP_MODE should already be set by load_environment() if marker file exists
            # But we use is_win_only_mode() for consistency and to handle edge cases
            is_win_only = is_win_only_mode()

            # Debug: Log why WIN-only mode is detected
            mcp_mode_before = os.environ.get("WIZ_MCP_MODE")
            logger.info(
                f"WIN-only detection in wiz_lifespan(): is_win_only={is_win_only}, "
                f"WIZ_MCP_MODE={mcp_mode_before}"
            )

            if is_win_only and not mcp_mode_before:
                # Log which marker file was found
                import pathlib
                current_file = pathlib.Path(__file__).resolve()
                package_root = current_file.parent.parent.parent.parent
                marker_paths = [
                    package_root / ".win-only",
                    pathlib.Path(os.getcwd()) / ".win-only",
                ]
                if package_root.name in ('win-mcp', 'wiz-mcp'):
                    marker_paths.append(package_root.parent / ".win-only")

                found_markers = [str(p) for p in marker_paths if p.exists()]
                if found_markers:
                    logger.debug(
                        f"WIN-only mode detected via .win-only marker file at: "
                        f"{', '.join(found_markers)}"
                    )
                else:
                    logger.warning(
                        "WIN-only mode detected but no marker file found - "
                        "this may indicate a bug in detection logic"
                    )

            # Ensure WIZ_MCP_MODE is set for other code that might check it
            if is_win_only and not os.environ.get("WIZ_MCP_MODE"):
                os.environ["WIZ_MCP_MODE"] = "win-only"
                logger.warning(
                    "WIN-only mode detected in wiz_lifespan() - this should not happen "
                    "if load_environment() worked correctly. WIZ_MCP_MODE was not set before."
                )

            if is_win_only:
                logger.info("WIN-only mode enabled - skipping dynamic tools and wiz_search")
                # Only register WIN APIs tool
                register_win_apis_tool(mcp_server)
                logger.info("Registered WIN APIs tool successfully (WIN-only mode).")
            else:
                # Full mode - register all tools
                register_dynamic_tools(mcp_server)
                logger.info("Registered dynamic tools successfully post authentication.")

                # Register our special wiz_search tool
                register_wiz_search_tool(mcp_server)
                logger.info("Registered wiz_search tool (if applicable).")

                # Register issue attack path structure tool
                register_issue_attack_path_structure_tool(mcp_server)
                logger.info("Registered get_issue_attack_path_structure tool.")

                # Register WIN APIs tool
                register_win_apis_tool(mcp_server)
                logger.info("Registered WIN APIs tool successfully.")
        except Exception as e:
            logger.error(f"Error registering tools: {e}")
            import traceback
            logger.error(f"Exception type: {type(e).__name__}")
            logger.error(f"Exception traceback: {traceback.format_exc()}")
            # Re-raise the exception with a clearer message
            raise Exception(f"Failed to register tools: {e}") from e

        yield context
    except Exception as e:
        # Log the error and re-raise
        logger.error(f"Error during mcp server initialization: {e}")
        raise


# Track if environment has been loaded
_env_loaded = False


def create_server(env_file_path=None) -> FastMCP:
    """
    Create a configured FastMCP server instance for the Wiz API.

    This function creates and configures a FastMCP server with the appropriate
    lifespan context manager and registers all available Wiz API tools.

    Args:
        env_file_path: Optional path to a .env file containing environment variables

    Returns:
        FastMCP: Configured FastMCP server instance ready to be run
    """
    global server, _env_loaded

    # Only load environment if it hasn't been loaded yet or if a specific path is provided
    if not _env_loaded or env_file_path:
        load_environment(env_file_path)
        _env_loaded = True

    # Create the server instance
    mcp = FastMCP(
        SERVER_NAME,
        description=SERVER_DESCRIPTION,
        lifespan=wiz_lifespan,
    )

    # Update the module-level server variable
    server = mcp

    return mcp


# Initialize the server with default settings
# This is used when the module is imported directly
server = create_server()

# Entry point for direct execution
if __name__ == "__main__":
    from wiz_mcp_server.cli import main

    main()
