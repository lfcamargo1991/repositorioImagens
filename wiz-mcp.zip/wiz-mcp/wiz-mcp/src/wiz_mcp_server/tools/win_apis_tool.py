"""
WIN APIs Tool for the Wiz MCP Server.

This tool provides access to Wiz Integration Network (WIN) API specifications
for partners and customers building custom integrations.

Enhanced to support:
- Category-based organization (issues, vulnerabilities, etc.)
- API specs (YAML/OpenAPI)
- Tutorials and documentation (MDX)
- Best practices
- Smart fallback and suggestions
"""

import os
import re
import yaml
from difflib import get_close_matches
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from mcp.server.fastmcp import FastMCP, Context

from wiz_mcp_server.utils.logger import get_logger

logger = get_logger()

# Hardcoded fallback path for development
DEFAULT_WIN_CONTENT_PATH = 'win-content'


class WinApiSpecsLoader:
    """Loads and manages WIN API specifications with category support."""

    def __init__(self):
        self.specs_path = self._get_specs_path()
        self.categories: Dict[str, Dict[str, Any]] = {}
        self.api_specs: Dict[str, Dict[str, Any]] = {}  # Flat lookup by api_name
        self.root_specs: Dict[str, Dict[str, Any]] = {}  # Root-level specs (generate-api-token)
        self._load_api_specs()

    def _get_specs_path(self) -> str:
        """Get the path to WIN content (folder containing 'api-specs') from environment or default."""
        mcp_mode = os.environ.get("WIZ_MCP_MODE", "full").lower()
        is_win_only = mcp_mode == "win-only"

        if is_win_only:
            path = os.getenv('WIN_CONTENT_PATH', DEFAULT_WIN_CONTENT_PATH)
        else:
            path = os.getenv('WIZ_WIN_CONTENT_PATH', DEFAULT_WIN_CONTENT_PATH)
        logger.info(f"Using WIN content path: {path}")
        return path

    def _parse_mdx_frontmatter(self, file_path: Path) -> Dict[str, Any]:
        """Parse YAML frontmatter from an MDX file."""
        try:
            content = file_path.read_text(encoding='utf-8')
            if not content.startswith('---'):
                return {}

            end_match = re.search(r'\n---\s*\n', content[3:])
            if not end_match:
                return {}

            frontmatter_text = content[3:end_match.start() + 3]
            return yaml.safe_load(frontmatter_text) or {}
        except Exception:
            return {}

    def _get_mdx_content_without_frontmatter(self, file_path: Path) -> str:
        """Get MDX content without the frontmatter."""
        try:
            content = file_path.read_text(encoding='utf-8')
            if not content.startswith('---'):
                return content

            end_match = re.search(r'\n---\s*\n', content[3:])
            if not end_match:
                return content

            # Return content after frontmatter
            return content[end_match.end() + 3:].strip()
        except Exception:
            return ""

    def _load_api_specs(self) -> None:
        """Load all API specifications from the specs directory."""
        try:
            specs_dir = Path(self.specs_path) / 'api-specs'
            if not specs_dir.exists():
                logger.warning(f"WIN content missing 'api-specs' directory: {specs_dir}")
                return

            # Load root-level specs (e.g., generate-api-token.yml)
            for file in specs_dir.iterdir():
                if file.is_file() and file.suffix in ('.yml', '.yaml'):
                    self._load_root_spec(file)

            # Load category folders
            for category_dir in specs_dir.iterdir():
                if category_dir.is_dir():
                    self._load_category(category_dir)

            logger.info(
                f"Loaded {len(self.categories)} categories, "
                f"{len(self.api_specs)} API specs, "
                f"{len(self.root_specs)} root specs"
            )

        except Exception as e:
            logger.error(f"Error loading WIN API specs from {self.specs_path}: {e}")

    def _load_root_spec(self, file_path: Path) -> None:
        """Load a root-level API spec (not in a category folder)."""
        try:
            content = file_path.read_text(encoding='utf-8')
            yaml_data = yaml.safe_load(content)

            if not yaml_data or 'info' not in yaml_data:
                return

            api_name = file_path.stem
            title = yaml_data.get('info', {}).get('title', api_name)

            self.root_specs[api_name] = {
                'title': title,
                'content': content,
                'file_path': str(file_path),
                'category': None
            }

            # Also add to flat api_specs lookup
            self.api_specs[api_name] = self.root_specs[api_name]

            logger.debug(f"Loaded root spec: {api_name}")
        except Exception as e:
            logger.error(f"Error loading root spec {file_path}: {e}")

    def _load_category(self, category_dir: Path) -> None:
        """Load all content from a category folder."""
        category_name = category_dir.name

        self.categories[category_name] = {
            'name': category_name,
            'index': None,
            'index_frontmatter': {},
            'specs': {},
            'docs': {}
        }

        for file in category_dir.iterdir():
            if not file.is_file():
                continue

            try:
                if file.name == 'index.mdx':
                    # Category overview
                    frontmatter = self._parse_mdx_frontmatter(file)
                    content = self._get_mdx_content_without_frontmatter(file)
                    self.categories[category_name]['index'] = content
                    self.categories[category_name]['index_frontmatter'] = frontmatter
                    logger.debug(f"Loaded index for category: {category_name}")

                elif file.suffix in ('.yml', '.yaml'):
                    # API spec
                    content = file.read_text(encoding='utf-8')
                    yaml_data = yaml.safe_load(content)

                    if not yaml_data or 'info' not in yaml_data:
                        continue

                    api_name = file.stem
                    title = yaml_data.get('info', {}).get('title', api_name)

                    spec_data = {
                        'title': title,
                        'content': content,
                        'file_path': str(file),
                        'category': category_name
                    }

                    self.categories[category_name]['specs'][api_name] = spec_data
                    self.api_specs[api_name] = spec_data
                    logger.debug(f"Loaded spec: {category_name}/{api_name}")

                elif file.suffix == '.mdx' and file.name != 'index.mdx':
                    # Tutorial or other docs
                    frontmatter = self._parse_mdx_frontmatter(file)
                    content = self._get_mdx_content_without_frontmatter(file)
                    doc_name = file.stem

                    self.categories[category_name]['docs'][doc_name] = {
                        'title': frontmatter.get('title', doc_name),
                        'description': frontmatter.get('description', ''),
                        'content': content,
                        'frontmatter': frontmatter,
                        'file_path': str(file)
                    }
                    logger.debug(f"Loaded doc: {category_name}/{doc_name}")

            except Exception as e:
                logger.error(f"Error loading file {file}: {e}")

    def get_available_apis(self) -> List[str]:
        """Get list of available API names."""
        return list(self.api_specs.keys())

    def get_available_categories(self) -> List[str]:
        """Get list of available categories."""
        return list(self.categories.keys())

    def get_api_spec(self, api_name: str) -> Optional[str]:
        """Get the raw YAML content for a specific API."""
        if api_name not in self.api_specs:
            return None
        return self.api_specs[api_name]['content']

    def get_api_title(self, api_name: str) -> Optional[str]:
        """Get the title for a specific API."""
        if api_name not in self.api_specs:
            return None
        return self.api_specs[api_name]['title']

    def get_api_category(self, api_name: str) -> Optional[str]:
        """Get the category for a specific API."""
        if api_name not in self.api_specs:
            return None
        return self.api_specs[api_name].get('category')

    def get_category_info(self, category_name: str) -> Optional[Dict[str, Any]]:
        """Get full category information including index, specs, and docs."""
        return self.categories.get(category_name)

    def get_category_overview(self, category_name: str) -> Optional[str]:
        """Get the index.mdx content for a category."""
        category = self.categories.get(category_name)
        if not category:
            return None
        return category.get('index')

    def get_related_docs(self, api_name: str) -> List[Dict[str, Any]]:
        """Get related documentation for an API (from same category)."""
        category_name = self.get_api_category(api_name)
        if not category_name:
            return []

        category = self.categories.get(category_name, {})
        docs = category.get('docs', {})

        # Return all docs from the category
        return [
            {'name': name, **doc_info}
            for name, doc_info in docs.items()
        ]

    def get_available_docs(self) -> Dict[str, str]:
        """Get all available doc names mapped to their category."""
        docs = {}
        for category_name, category_info in self.categories.items():
            for doc_name in category_info.get('docs', {}).keys():
                docs[doc_name] = category_name
        return docs

    def get_doc(self, doc_name: str) -> Optional[Dict[str, Any]]:
        """Get a specific doc by name (searches all categories)."""
        for category_name, category_info in self.categories.items():
            if doc_name in category_info.get('docs', {}):
                doc = category_info['docs'][doc_name].copy()
                doc['category'] = category_name
                return doc
        return None

    def resolve_doc_name(self, doc_query: str) -> Tuple[Optional[str], List[str], bool]:
        """
        Resolve a doc query to an actual doc name.
        Returns (exact_match, suggestions, is_good_match).
        """
        all_docs = list(self.get_available_docs().keys())

        # Normalize query
        query = doc_query.lower().replace('_', '-').replace(' ', '-')

        # Exact match
        if query in [d.lower() for d in all_docs]:
            return next(d for d in all_docs if d.lower() == query), [], True

        # Find suggestions
        suggestions, is_good_match = self.find_closest_match(doc_query, all_docs)

        return None, suggestions, is_good_match

    def format_doc_response(self, doc_name: str) -> str:
        """Format a complete response for a doc request (full content, no truncation)."""
        doc = self.get_doc(doc_name)
        if not doc:
            return f"Error: Document '{doc_name}' not found"

        parts = []

        # Header
        parts.append(f"# {doc['title']}")
        if doc.get('description'):
            parts.append(f"*{doc['description']}*")
        parts.append(f"\nCategory: {doc['category']}")
        parts.append("")

        # Full content - no truncation
        parts.append(doc.get('content', ''))

        return "\n".join(parts)

    def find_closest_match(
        self, query: str, candidates: List[str], n: int = 3, min_similarity: float = 0.5
    ) -> Tuple[List[str], bool]:
        """
        Find closest matches for a query string.

        Returns:
            Tuple of (matches, is_good_match) where is_good_match indicates
            if the matches are reasonably similar to the query.
        """
        # Normalize query
        query_normalized = query.lower().replace('_', '-').replace(' ', '-')

        # Try exact match first
        if query_normalized in [c.lower() for c in candidates]:
            exact = [c for c in candidates if c.lower() == query_normalized]
            return exact, True

        # Try contains match (high confidence)
        contains_matches = [c for c in candidates if query_normalized in c.lower() or c.lower() in query_normalized]
        if contains_matches:
            return contains_matches[:n], True

        # Use difflib for fuzzy matching with higher cutoff for "good" matches
        matches = get_close_matches(query_normalized, [c.lower() for c in candidates], n=n, cutoff=min_similarity)

        # Map back to original case
        result = []
        for match in matches:
            for candidate in candidates:
                if candidate.lower() == match and candidate not in result:
                    result.append(candidate)
                    break

        # If we found matches with good similarity, return them
        if result:
            return result, True

        # Try with lower cutoff but mark as not a good match
        weak_matches = get_close_matches(query_normalized, [c.lower() for c in candidates], n=n, cutoff=0.3)
        weak_result = []
        for match in weak_matches:
            for candidate in candidates:
                if candidate.lower() == match and candidate not in weak_result:
                    weak_result.append(candidate)
                    break

        return weak_result, False

    def resolve_category(self, category_query: str) -> Tuple[Optional[str], List[str], bool]:
        """
        Resolve a category query to an actual category name.
        Returns (exact_match, suggestions, is_good_match).
        """
        categories = self.get_available_categories()

        # Normalize query
        query = category_query.lower().replace('_', '-').replace(' ', '-')

        # Exact match
        if query in [c.lower() for c in categories]:
            return next(c for c in categories if c.lower() == query), [], True

        # Find suggestions
        suggestions, is_good_match = self.find_closest_match(category_query, categories)

        return None, suggestions, is_good_match

    def resolve_api_name(self, api_query: str) -> Tuple[Optional[str], List[str], bool]:
        """
        Resolve an API query to an actual API name.
        Returns (exact_match, suggestions, is_good_match).
        """
        apis = self.get_available_apis()

        # Normalize query
        query = api_query.lower().replace('_', '-').replace(' ', '-')

        # Exact match
        if query in [a.lower() for a in apis]:
            return next(a for a in apis if a.lower() == query), [], True

        # Find suggestions
        suggestions, is_good_match = self.find_closest_match(api_query, apis)

        return None, suggestions, is_good_match

    def get_full_api_list_for_description(self) -> str:
        """Generate comprehensive API list for tool description."""
        lines = []

        # Authentication
        lines.append("## AUTHENTICATION API")
        lines.append("- **generate-api-token**: Get OAuth access token (REQUIRED FIRST STEP)")
        lines.append("")

        # Categories with their APIs
        lines.append("## AVAILABLE CATEGORIES AND APIs")
        lines.append("")

        for category_name in sorted(self.categories.keys()):
            category_info = self.categories[category_name]
            frontmatter = category_info.get('index_frontmatter', {})
            title = frontmatter.get('title', category_name.replace('-', ' ').title())
            description = frontmatter.get('description', '')

            lines.append(f"### {title} (category=\"{category_name}\")")
            if description:
                # Truncate long descriptions
                desc_short = description[:200] + "..." if len(description) > 200 else description
                lines.append(f"*{desc_short}*")

            # List APIs in category
            specs = category_info.get('specs', {})
            if specs:
                lines.append("APIs:")
                for api_name, spec_info in specs.items():
                    lines.append(f"  - {api_name}: {spec_info['title']}")

            # Note if tutorials available
            docs = category_info.get('docs', {})
            if docs:
                lines.append(f"Tutorials: {len(docs)} available")

            lines.append("")

        return "\n".join(lines)

    def format_api_response(
        self, api_name: str, include_category_context: bool = True, include_tutorials: bool = True
    ) -> str:
        """Format a complete response for an API request."""
        if api_name not in self.api_specs:
            return f"Error: API '{api_name}' not found"

        spec_info = self.api_specs[api_name]
        category_name = spec_info.get('category')

        parts = []

        # Header
        parts.append(f"# WIN API: {spec_info['title']}")
        parts.append(f"API Name: {api_name}")
        if category_name:
            parts.append(f"Category: {category_name}")
        parts.append("")

        # Category context
        if include_category_context and category_name:
            category_info = self.categories.get(category_name, {})
            index_content = category_info.get('index')
            if index_content:
                parts.append("## Category Overview")
                parts.append("")
                if len(index_content) > 1500:
                    parts.append(index_content[:1500] + "\n\n... (truncated, use category parameter for full overview)")
                else:
                    parts.append(index_content)
                parts.append("")

        # API Specification
        parts.append("## API Specification (OpenAPI/YAML)")
        parts.append("")
        parts.append("```yaml")
        parts.append(spec_info['content'])
        parts.append("```")
        parts.append("")

        # Related tutorials
        if include_tutorials and category_name:
            related_docs = self.get_related_docs(api_name)
            if related_docs:
                parts.append("## Related Documentation")
                parts.append("")
                for doc in related_docs:
                    parts.append(f"### {doc['title']}")
                    if doc.get('description'):
                        parts.append(f"*{doc['description']}*")
                    parts.append("")
                    content = doc.get('content', '')
                    if len(content) > 3000:
                        parts.append(content[:3000] + "\n\n... (truncated)")
                    else:
                        parts.append(content)
                    parts.append("")

        return "\n".join(parts)

    def format_category_response(self, category_name: str) -> str:
        """Format a complete response for a category request."""
        if category_name not in self.categories:
            return f"Error: Category '{category_name}' not found"

        category_info = self.categories[category_name]
        frontmatter = category_info.get('index_frontmatter', {})

        parts = []

        # Header
        title = frontmatter.get('title', category_name.replace('-', ' ').title())
        parts.append(f"# WIN API Category: {title}")
        parts.append("")

        # Category overview (full content)
        index_content = category_info.get('index')
        if index_content:
            parts.append(index_content)
            parts.append("")

        # Available APIs in this category
        specs = category_info.get('specs', {})
        if specs:
            parts.append("## Available APIs in this Category")
            parts.append("")
            for api_name, spec_info in specs.items():
                parts.append(f"- **{api_name}**: {spec_info['title']}")
            parts.append("")
            parts.append("Use `api_name=\"<name>\"` to get the full API specification.")
            parts.append("")

        # Available tutorials/docs
        docs = category_info.get('docs', {})
        if docs:
            parts.append("## Available Documentation")
            parts.append("")
            for doc_name, doc_info in docs.items():
                parts.append(f"- **{doc_name}**: {doc_info['title']}")
                if doc_info.get('description'):
                    parts.append(f"  {doc_info['description']}")
            parts.append("")
            parts.append("Use `doc_name=\"<name>\"` to get full documentation content.")
            parts.append("")

        return "\n".join(parts)

    def format_suggestions_response(
        self, query: str, query_type: str, suggestions: List[str], show_all: bool = False
    ) -> str:
        """Format a helpful response when exact match not found."""
        parts = []

        if query_type == "category":
            parts.append(f"# Category '{query}' not found")
            parts.append("")

            if suggestions and not show_all:
                parts.append("**Did you mean one of these categories?**")
                for s in suggestions:
                    cat_info = self.categories.get(s, {})
                    fm = cat_info.get('index_frontmatter', {})
                    title = fm.get('title', s.replace('-', ' ').title())
                    parts.append(f"- **{s}**: {title}")
                parts.append("")
                parts.append(f"Try: `category=\"{suggestions[0]}\"`")
            else:
                parts.append("**Available categories:**")
                parts.append("")
                for cat in sorted(self.categories.keys()):
                    cat_info = self.categories.get(cat, {})
                    fm = cat_info.get('index_frontmatter', {})
                    title = fm.get('title', cat.replace('-', ' ').title())
                    desc = fm.get('description', '')
                    desc_short = (desc[:100] + "...") if len(desc) > 100 else desc
                    parts.append(f"- **{cat}**: {title}")
                    if desc_short:
                        parts.append(f"  {desc_short}")
                parts.append("")
                parts.append("Use `category=\"<name>\"` to explore a category.")

        elif query_type == "api":
            parts.append(f"# API '{query}' not found")
            parts.append("")

            if suggestions and not show_all:
                parts.append("**Did you mean one of these APIs?**")
                for s in suggestions:
                    api_info = self.api_specs.get(s, {})
                    title = api_info.get('title', s)
                    category = api_info.get('category', 'root')
                    parts.append(f"- **{s}**: {title} (in {category})")
                parts.append("")
                parts.append(f"Try: `api_name=\"{suggestions[0]}\"`")
            else:
                parts.append("**Use `category` parameter first to explore available APIs.**")
                parts.append("")
                parts.append("**Available categories:**")
                for cat in sorted(self.categories.keys()):
                    cat_info = self.categories.get(cat, {})
                    fm = cat_info.get('index_frontmatter', {})
                    title = fm.get('title', cat.replace('-', ' ').title())
                    parts.append(f"- **{cat}**: {title}")
                parts.append("")
                parts.append("Use `category=\"<name>\"` to see available APIs in that category.")

        return "\n".join(parts)


# Global instance
_win_api_loader = None


def get_win_api_loader() -> WinApiSpecsLoader:
    """Get the global WIN API loader instance."""
    global _win_api_loader
    if _win_api_loader is None:
        _win_api_loader = WinApiSpecsLoader()
    return _win_api_loader


def register_win_apis_tool(mcp: FastMCP) -> None:
    """Register the WIN APIs tool with the FastMCP server."""
    loader = get_win_api_loader()

    # Generate comprehensive description with all categories and APIs
    full_api_list = loader.get_full_api_list_for_description()
    categories_list = ", ".join(sorted(loader.get_available_categories()))

    description = f"""WIZ INTEGRATION NETWORK (WIN) API REFERENCE - Build integrations with Wiz

Use this tool to get API specifications, tutorials, and implementation guidance for building Wiz integrations.

## HOW TO USE THIS TOOL

**Step 1: Explore a category to understand available APIs**
```
category="vulnerabilities"  → Learn about vulnerability APIs, use cases, and which API to choose
category="issues"           → Learn about Issues APIs
category="enrichment"       → Learn about external enrichment APIs and schemas
```

**Step 2: Get specific API specification**
```
api_name="vulnerability-finding"  → Get full OpenAPI spec
api_name="issues-query"           → Get Issues API spec
api_name="generate-api-token"     → Get authentication API spec (START HERE)
```

**Step 3: Get full documentation/schema (when needed)**
```
doc_name="vuln-scan-schema-v2"           → Get full vulnerability enrichment schema
doc_name="sca-app-vuln-findings-schema"  → Get full SCA findings schema
doc_name="issues-tutorial"               → Get full issues tutorial
```

**Available Categories:** {categories_list}

## AUTHENTICATION (ALWAYS START HERE)

Use `api_name="generate-api-token"` to get authentication details.

Authentication flow:
1. POST to `https://auth.{{WIZ_ENV}}.wiz.io/oauth/token`
   - Content-Type: `application/x-www-form-urlencoded` (NOT JSON!)
   - Body: grant_type=client_credentials, client_id=YOUR_ID, client_secret=YOUR_SECRET, audience=wiz-api
2. Decode JWT response to get `dc` field (data center)
3. Make GraphQL requests to `https://api.{{DC}}.{{WIZ_ENV}}.wiz.io/graphql`
   - Header: `Authorization: Bearer {{access_token}}`

{full_api_list}

## USAGE TIPS

- Start with `category` to understand what APIs are available
- Use `api_name` to get the full OpenAPI spec when ready to implement
- Use `doc_name` to get full documentation, tutorials, or schema definitions
- Category responses list available docs - use `doc_name` to fetch them in full
- If you're unsure which API to use, start with a category overview

## WHEN TO USE THIS TOOL

✅ USE for: Building integrations, writing code to query Wiz APIs, getting GraphQL queries, enrichment schemas
❌ DON'T USE for: General Wiz questions, UI help, understanding Wiz concepts (use docs tool instead)"""

    @mcp.tool(description=description)
    async def win_apis(
        api_name: str = None,
        category: str = None,
        doc_name: str = None,
        ctx: Context = None
    ) -> str:
        """
        Get WIN API specification, category overview, or documentation for building Wiz integrations.

        Args:
            api_name: Name of a specific API (e.g., "vulnerability-finding", "issues-query")
            category: Name of a category (e.g., "vulnerabilities", "issues", "enrichment")
            doc_name: Name of a specific doc/schema (e.g., "vuln-scan-schema-v2", "issues-tutorial")

        Returns:
            API specification, category overview, or full documentation content.
            If not found, returns suggestions for similar matches.
        """
        logger.info(f"WIN APIs tool called with api_name={api_name}, category={category}, doc_name={doc_name}")

        loader = get_win_api_loader()

        # Handle help/list requests
        if api_name in ("list", "list-all", "help", "?") or (not api_name and not category and not doc_name):
            return loader.get_full_api_list_for_description()

        # Handle doc_name request (full documentation content)
        if doc_name:
            exact_match, suggestions, is_good_match = loader.resolve_doc_name(doc_name)

            if exact_match:
                result = loader.format_doc_response(exact_match)
                logger.info(f"Successfully returned full doc for: {exact_match}")
                return result

            # Only auto-use suggestion if it's a good match
            if suggestions and is_good_match:
                logger.info(f"Doc '{doc_name}' not found, using suggestion: {suggestions[0]}")
                result = loader.format_doc_response(suggestions[0])
                header = f"# Note: Document '{doc_name}' not found. Showing '{suggestions[0]}' instead.\n\n"
                if len(suggestions) > 1:
                    header += f"Other similar docs: {', '.join(suggestions[1:])}\n\n---\n\n"
                return header + result

            # No good match - show available docs
            all_docs = loader.get_available_docs()
            parts = [f"# Document '{doc_name}' not found", ""]
            parts.append("**Available documentation by category:**")
            parts.append("")
            docs_by_category: Dict[str, List[str]] = {}
            for d, cat in all_docs.items():
                if cat not in docs_by_category:
                    docs_by_category[cat] = []
                docs_by_category[cat].append(d)
            for cat in sorted(docs_by_category.keys()):
                parts.append(f"**{cat}:**")
                for d in sorted(docs_by_category[cat]):
                    parts.append(f"  - {d}")
            parts.append("")
            parts.append("Use `doc_name=\"<name>\"` to get full documentation.")
            return "\n".join(parts)

        # Handle category request
        if category:
            # Try to resolve category (with fuzzy matching)
            exact_match, suggestions, is_good_match = loader.resolve_category(category)

            if exact_match:
                result = loader.format_category_response(exact_match)
                logger.info(f"Successfully returned category overview for: {exact_match}")
                return result

            # Only auto-use suggestion if it's a good match
            if suggestions and is_good_match:
                logger.info(f"Category '{category}' not found, using suggestion: {suggestions[0]}")
                result = loader.format_category_response(suggestions[0])
                header = f"# Note: Category '{category}' not found. Showing '{suggestions[0]}' instead.\n\n"
                if len(suggestions) > 1:
                    header += f"Other similar categories: {', '.join(suggestions[1:])}\n\n---\n\n"
                return header + result

            # No good match - show all categories
            logger.info(f"Category '{category}' not found, no good match - showing all categories")
            return loader.format_suggestions_response(category, "category", suggestions, show_all=True)

        # Handle API request
        if api_name:
            # Try to resolve API name (with fuzzy matching)
            exact_match, suggestions, is_good_match = loader.resolve_api_name(api_name)

            if exact_match:
                result = loader.format_api_response(exact_match)
                logger.info(f"Successfully returned WIN API spec for: {exact_match}")
                return result

            # Only auto-use suggestion if it's a good match
            if suggestions and is_good_match:
                logger.info(f"API '{api_name}' not found, using suggestion: {suggestions[0]}")
                result = loader.format_api_response(suggestions[0])
                header = f"# Note: API '{api_name}' not found. Showing '{suggestions[0]}' instead.\n\n"
                if len(suggestions) > 1:
                    other_apis = ", ".join(suggestions[1:])
                    header += f"Other similar APIs: {other_apis}\n\n---\n\n"
                return header + result

            # No good match - show helpful message with all categories
            logger.info(f"API '{api_name}' not found, no good match - showing all categories")
            return loader.format_suggestions_response(api_name, "api", suggestions, show_all=True)

        return loader.get_full_api_list_for_description()

    logger.info(
        f"Registered WIN APIs tool with {len(loader.get_available_categories())} categories "
        f"and {len(loader.get_available_apis())} APIs"
    )
