"""
Tools package for the Wiz MCP Server.

This package provides tools for the Wiz MCP Server.
"""

# Import dynamic tools functionality
from .dynamic_tools import register_dynamic_tools
from .execute_tool import execute_tool_directly
from .fetch_tools import fetch_tools
from .tool_definition_classes import ToolDefinition, ToolParameter
from .win_apis_tool import register_win_apis_tool

# Conditionally import wiz_search_tool (not available in WIN-only mode)
try:
    from .wiz_search_tool import register_wiz_search_tool
except ImportError:
    # WIN-only mode: wiz_search_tool is not included
    def register_wiz_search_tool(mcp):
        """Stub function for WIN-only mode where wiz_search_tool is not available."""
        pass

# Conditionally import issue attack path structure tool (not available in WIN-only mode)
try:
    from .issue_attack_path_structure_tool import register_issue_attack_path_structure_tool
except ImportError:
    # WIN-only mode: issue_attack_path_structure_tool is not included
    def register_issue_attack_path_structure_tool(mcp):
        """Stub function for WIN-only mode where issue_attack_path_structure_tool is not available."""
        pass

__all__ = ["register_dynamic_tools", "fetch_tools", "ToolDefinition", "ToolParameter",
           "execute_tool_directly", "register_wiz_search_tool", "register_win_apis_tool",
           "register_issue_attack_path_structure_tool"]
