"""
Issue Attack Path Structure Tool.

Retrieves and processes Wiz Security Graph data for a given issue, returning
a structured graph representation with nodes and edges.
"""

import traceback
from typing import Any, Dict, List, Optional, Set, Tuple

from mcp.server.fastmcp import Context, FastMCP

from wiz_mcp_server.utils.graphql_client import execute_graphql_query
from wiz_mcp_server.utils.logger import get_logger

logger = get_logger()

SECURITY_GRAPH_INTERNET_NODE_ID = "_public_internet_"
SPEC_FILE_NAME = "attack_path_spec_v1.json"


def _load_attack_path_spec() -> Dict[str, Any]:
    """Load the versioned attack-path spec that defines layer behaviors."""
    import json
    from pathlib import Path

    here = Path(__file__).resolve().parent
    spec_path = here / SPEC_FILE_NAME
    try:
        return json.loads(spec_path.read_text())
    except Exception as e:
        logger.warning(f"Failed loading attack path spec at {spec_path}: {e}", exc_info=True)
        return {"version": 1, "internetNodeId": SECURITY_GRAPH_INTERNET_NODE_ID}


def _compact(values: Optional[List[Any]]) -> List[Any]:
    if not values or not isinstance(values, list):
        return []
    return [v for v in values if v is not None]


def _entity_type(entity: Dict[str, Any]) -> Optional[str]:
    if not isinstance(entity, dict):
        return None
    t = entity.get("type")
    return str(t) if t is not None else None


def _entity_id(entity: Dict[str, Any]) -> Optional[str]:
    if not isinstance(entity, dict):
        return None
    v = entity.get("id")
    return str(v) if v is not None else None


def _as_graph_entity_node(entity: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a graph entity to a node structure."""
    return {
        "id": _entity_id(entity),
        "type": _entity_type(entity),
        "name": entity.get("name"),
    }


def _internet_node() -> Dict[str, Any]:
    return {
        "id": SECURITY_GRAPH_INTERNET_NODE_ID,
        "type": "INTERNET",
        "name": "Internet",
    }


def _deleted_entity_node_id(path_id: str, index: int) -> str:
    return f"_path_._deleted_entity_.{path_id}.{index}"


def _deleted_entity_node(path_id: str, index: int) -> Dict[str, Any]:
    node_id = _deleted_entity_node_id(path_id, index)
    return {
        "id": node_id,
        "type": "ANY",
        "name": "Deleted Resource",
    }


def _deleted_resource_mock_entity(path_id: str, index: int) -> Dict[str, Any]:
    """Create a mock entity for deleted resources in lateral movement paths."""
    return {
        "id": f"_deleted_lm_{path_id}_{index}",
        "type": "ANY",
        "name": "Deleted Resource",
    }


def _calc_items_from_path(
    *,
    path_id: str,
    entities: List[Optional[Dict[str, Any]]],
    root_node_id: Optional[str],
) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    """Process a path and return nodes and edges."""
    nodes: Dict[str, Dict[str, Any]] = {}
    edges: Dict[str, Dict[str, Any]] = {}

    prev_node_id: Optional[str] = None
    if root_node_id:
        prev_node_id = root_node_id

    reverse_path = list(reversed(entities or []))
    for idx, path_node in enumerate(reverse_path):
        if path_node is not None and isinstance(path_node, dict) and path_node.get("id"):
            node_id = str(path_node.get("id"))
            nodes[node_id] = _as_graph_entity_node(path_node)
        else:
            node_id = _deleted_entity_node_id(path_id, idx)
            nodes[node_id] = _deleted_entity_node(path_id, idx)

        if prev_node_id:
            link_id = f"{prev_node_id}->{node_id}"
            edges[link_id] = {
                "id": link_id,
                "from": prev_node_id,
                "to": node_id,
                "type": "path_link",
                "properties": {"_pathId": path_id},
            }

        prev_node_id = node_id

    return nodes, edges


def _extract_graph_entities_from_search_results(search_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    entities: List[Dict[str, Any]] = []
    for rec in search_results or []:
        if not isinstance(rec, dict):
            continue
        for ent in rec.get("entities") or []:
            if isinstance(ent, dict):
                entities.append(ent)
    return entities


def _collect_public_exposure_endpoint_ids(graph_entities: List[Dict[str, Any]]) -> Set[str]:
    endpoint_ids: Set[str] = set()
    for entity in graph_entities or []:
        pe = entity.get("publicExposures")
        nodes = pe.get("nodes") if isinstance(pe, dict) else None
        for exposure in nodes or []:
            if not isinstance(exposure, dict):
                continue
            for ep in exposure.get("applicationEndpoints") or []:
                if isinstance(ep, dict) and ep.get("id"):
                    endpoint_ids.add(str(ep.get("id")))
    return endpoint_ids


# ---------------------------------------------------------------------------
# Evidence Query Fetching
# ---------------------------------------------------------------------------

ISSUE_EVIDENCE_QUERY_GQL = """
query GetIssueEvidenceQuery($issueId: ID!) {
  issue(id: $issueId) {
    id
    evidenceQuery
  }
}
"""


async def fetch_issue_evidence_query(
    issue_id: str,
    auth_headers: Dict[str, str],
    dc: str,
    env: str,
    context_params: Optional[Dict[str, Any]] = None,
) -> Optional[Any]:
    """Fetch the evidenceQuery field for an issue."""
    variables = {"issueId": issue_id}

    result = await execute_graphql_query(
        query=ISSUE_EVIDENCE_QUERY_GQL,
        variables=variables,
        auth_headers=auth_headers,
        dc=dc,
        env=env,
        context_params=context_params or {},
    )

    if isinstance(result, dict) and "error" in result:
        logger.warning(f"Error fetching evidence query for issue {issue_id}: {result.get('error')}")
        return None
    if isinstance(result, dict) and "errors" in result:
        logger.warning(f"GraphQL errors fetching evidence query: {result.get('errors')}")
        return None

    data = result.get("data") if isinstance(result, dict) else None
    issue = data.get("issue") if isinstance(data, dict) else None

    if not isinstance(issue, dict):
        return None

    return issue.get("evidenceQuery")


# ---------------------------------------------------------------------------
# Query Map Logic
# ---------------------------------------------------------------------------

class QueryMapNode:
    """Represents a node in the query map."""

    def __init__(
        self,
        subquery: Dict[str, Any],
        search_result_entities_index: int = -1,
        level: int = -1,
    ):
        self.subquery = subquery
        self.search_result_entities_index = search_result_entities_index
        self.level = level
        self.links: List["QueryMapLink"] = []

    @property
    def select(self) -> bool:
        return bool(self.subquery.get("select", True))

    @property
    def aggregate(self) -> bool:
        return bool(self.subquery.get("aggregate", False))


class QueryMapLink:
    """Represents a link between two query map nodes."""

    def __init__(self, to_node: QueryMapNode, is_leap_link: bool = False):
        self.to = to_node
        self.is_leap_link = is_leap_link


def _get_query_subqueries(
    query: Dict[str, Any],
    omit_negated: bool = True,
) -> List[Dict[str, Any]]:
    """Flatten the query tree into a list of subqueries."""
    subqueries: List[Dict[str, Any]] = []

    def traverse(node: Dict[str, Any]) -> None:
        if not isinstance(node, dict):
            return

        subqueries.append(node)

        relationships = node.get("relationships") or []
        for rel in relationships:
            if not isinstance(rel, dict):
                continue

            if omit_negated and rel.get("negate"):
                continue

            with_node = rel.get("with")
            if isinstance(with_node, dict):
                traverse(with_node)

    traverse(query)
    return subqueries


def _calc_graph_query_map(query: Dict[str, Any]) -> List[QueryMapNode]:
    """Build a query map from an evidence query."""
    if not isinstance(query, dict):
        return []

    subqueries = _get_query_subqueries(query, omit_negated=True)

    subquery_to_node: Dict[int, QueryMapNode] = {}
    query_map_all: List[QueryMapNode] = []

    for sq in subqueries:
        node = QueryMapNode(subquery=sq)
        subquery_to_node[id(sq)] = node
        query_map_all.append(node)

    for node in query_map_all:
        relationships = node.subquery.get("relationships") or []
        for rel in relationships:
            if not isinstance(rel, dict):
                continue
            if rel.get("negate"):
                continue

            with_node = rel.get("with")
            if isinstance(with_node, dict):
                target = subquery_to_node.get(id(with_node))
                if target:
                    node.links.append(QueryMapLink(to_node=target))

    def create_leaping_links(node: QueryMapNode) -> List[QueryMapLink]:
        result: List[QueryMapLink] = []
        for link in node.links:
            if link.to.select:
                result.append(link)
            else:
                for far_link in create_leaping_links(link.to):
                    result.append(QueryMapLink(to_node=far_link.to, is_leap_link=True))
        return result

    for node in query_map_all:
        node.links = create_leaping_links(node)

    query_map = [n for n in query_map_all if n.select or n.aggregate]

    for idx, node in enumerate(query_map):
        node.search_result_entities_index = idx
        if idx == 0:
            node.level = 1
        for link in node.links:
            link.to.level = node.level + 1

    return query_map


def _create_edges_from_query_map(
    query_map: List[QueryMapNode],
    search_result: Dict[str, Any],
    nodes_by_id: Dict[str, Dict[str, Any]],
    edges_by_id: Dict[str, Dict[str, Any]],
) -> None:
    """Create edges based on the query map and a single search result record."""
    entities = search_result.get("entities") or []
    if not isinstance(entities, list):
        return

    entity_by_index: Dict[int, Optional[Dict[str, Any]]] = {}

    for node in query_map:
        idx = node.search_result_entities_index
        if idx < 0 or idx >= len(entities):
            entity_by_index[idx] = None
            continue

        entity = entities[idx]
        if entity and isinstance(entity, dict):
            eid = _entity_id(entity)
            if eid and eid not in nodes_by_id:
                nodes_by_id[eid] = _as_graph_entity_node(entity)
            entity_by_index[idx] = entity
        else:
            entity_by_index[idx] = None

    for node in query_map:
        from_entity = entity_by_index.get(node.search_result_entities_index)
        if not from_entity:
            continue
        from_id = _entity_id(from_entity)
        if not from_id:
            continue

        for link in node.links:
            to_entity = entity_by_index.get(link.to.search_result_entities_index)
            if not to_entity:
                continue
            to_id = _entity_id(to_entity)
            if not to_id:
                continue

            if from_id == to_id:
                continue

            edge_id = f"{from_id}->{to_id}"
            reverse_edge_id = f"{to_id}->{from_id}"

            if edge_id in edges_by_id or reverse_edge_id in edges_by_id:
                continue

            edges_by_id[edge_id] = {
                "id": edge_id,
                "from": from_id,
                "to": to_id,
                "type": "query_link",
                "properties": {"_source": "evidence_query"},
            }


def _extra_misc_paths(
    *,
    entity: Dict[str, Any],
    public_exposure_endpoint_ids: Set[str],
) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    """Generate extra paths for special entity types."""
    eid = _entity_id(entity)
    etype = _entity_type(entity)
    if not eid or not etype:
        return {}, {}

    if etype == "ENDPOINT" and eid in public_exposure_endpoint_ids:
        return {}, {}

    props = entity.get("properties") if isinstance(entity.get("properties"), dict) else {}

    should_connect = False
    if etype == "ENDPOINT":
        should_connect = True
    elif etype == "PREDEFINED_GROUP" and props.get("groupType") == "AllUsers":
        should_connect = True
    elif etype == "REPOSITORY" and bool(props.get("isPublic")):
        should_connect = True

    if not should_connect:
        return {}, {}

    nodes, edges = _calc_items_from_path(
        path_id=f"{etype.lower()}_to_internet_node_path",
        entities=[entity],
        root_node_id=SECURITY_GRAPH_INTERNET_NODE_ID,
    )
    return nodes, edges


def _build_attack_path_items(
    *,
    graph_search_nodes: List[Dict[str, Any]],
    is_network_path_expanded: bool,
    spec: Optional[Dict[str, Any]] = None,
    evidence_query: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build attack path graph structure from graphSearch results."""
    spec = spec or _load_attack_path_spec()
    internet_node_id = spec.get("internetNodeId") or SECURITY_GRAPH_INTERNET_NODE_ID

    search_result_entities = _extract_graph_entities_from_search_results(graph_search_nodes or [])

    public_exposure_endpoint_ids = _collect_public_exposure_endpoint_ids(search_result_entities)

    nodes_by_id: Dict[str, Dict[str, Any]] = {}
    edges_by_id: Dict[str, Dict[str, Any]] = {}

    nodes_by_id[internet_node_id] = _internet_node()

    def _merge(n: Dict[str, Dict[str, Any]], e: Dict[str, Dict[str, Any]]) -> None:
        nodes_by_id.update(n)
        edges_by_id.update(e)

    for entity in search_result_entities:
        if not isinstance(entity, dict):
            continue
        eid = _entity_id(entity)
        if eid:
            nodes_by_id[eid] = _as_graph_entity_node(entity)

        # Public exposure paths
        pe_spec = spec.get("publicExposure") or {}
        pe_field = pe_spec.get("exposureField", "publicExposures")
        pe_nodes_field = pe_spec.get("nodesField", "nodes")
        pe_path_field = pe_spec.get("pathField", "path")
        pe_endpoints_field = pe_spec.get("applicationEndpointsField", "applicationEndpoints")
        pe_ignore_no_eps = bool(pe_spec.get("ignorePathsWithoutEndpoints", True))
        pe_insert_after_resource = bool(pe_spec.get("insertEndpointsAfterResource", True))
        pe_collapse = bool(pe_spec.get("collapseNetworkPathWhenNotExpanded", True))
        pe_root = pe_spec.get("root", "INTERNET")

        public_exposures_obj = entity.get(pe_field)
        public_exposures = (
            public_exposures_obj.get(pe_nodes_field)
            if isinstance(public_exposures_obj, dict) else None
        )
        if isinstance(public_exposures, list):
            for exposure in public_exposures:
                if not isinstance(exposure, dict):
                    continue
                endpoints = _compact(exposure.get(pe_endpoints_field))
                if pe_ignore_no_eps and not endpoints:
                    continue

                path_entities = exposure.get(pe_path_field) or []
                if not isinstance(path_entities, list):
                    path_entities = []

                augmented = list(path_entities)
                if pe_collapse and (not is_network_path_expanded):
                    augmented = [augmented[0]] if augmented else []

                root_node_id = internet_node_id if pe_root == "INTERNET" else None

                if pe_insert_after_resource and endpoints:
                    if not augmented:
                        for ep in endpoints:
                            p_nodes, p_edges = _calc_items_from_path(
                                path_id=str(exposure.get("id") or pe_field),
                                entities=[ep],
                                root_node_id=root_node_id,
                            )
                            _merge(p_nodes, p_edges)
                        continue

                    resource = augmented[0]
                    rest = augmented[1:]
                    for ep in endpoints:
                        entities_for_path: List[Optional[Dict[str, Any]]] = [resource, ep, *rest]
                        p_nodes, p_edges = _calc_items_from_path(
                            path_id=str(exposure.get("id") or pe_field),
                            entities=entities_for_path,
                            root_node_id=root_node_id,
                        )
                        _merge(p_nodes, p_edges)
                else:
                    p_nodes, p_edges = _calc_items_from_path(
                        path_id=str(exposure.get("id") or pe_field),
                        entities=augmented,
                        root_node_id=root_node_id,
                    )
                    _merge(p_nodes, p_edges)

        # Internal exposures
        ie_spec = spec.get("internalExposure") or {}
        ie_fields = ie_spec.get("exposureFields") or ["otherSubscriptionExposures", "otherVnetExposures"]
        ie_nodes_field = ie_spec.get("nodesField", "nodes")
        ie_path_field = ie_spec.get("pathField", "path")
        for exposure_field in ie_fields:
            exp_obj = entity.get(exposure_field)
            exp_nodes = exp_obj.get(ie_nodes_field) if isinstance(exp_obj, dict) else None
            if not isinstance(exp_nodes, list):
                continue
            for exp in exp_nodes:
                if not isinstance(exp, dict):
                    continue
                path_entities = exp.get(ie_path_field) or []
                if not isinstance(path_entities, list):
                    continue
                p_nodes, p_edges = _calc_items_from_path(
                    path_id=str(exp.get("id") or exposure_field),
                    entities=path_entities,
                    root_node_id=None,
                )
                _merge(p_nodes, p_edges)

        # Code source path
        cs_spec = spec.get("codeSource") or {}
        cs_field = cs_spec.get("field", "codeSourcePath")
        cs_nodes_field = cs_spec.get("nodesField", "nodes")
        cs_path_entities_field = cs_spec.get("pathEntitiesField", "pathEntities")
        cs_obj = entity.get(cs_field)
        cs_nodes = cs_obj.get(cs_nodes_field) if isinstance(cs_obj, dict) else None
        if isinstance(cs_nodes, list) and eid:
            for cs in cs_nodes:
                if not isinstance(cs, dict):
                    continue
                path_entities = cs.get(cs_path_entities_field) or []
                if not isinstance(path_entities, list):
                    path_entities = []
                p_nodes, p_edges = _calc_items_from_path(
                    path_id=str(cs.get("id") or cs_field),
                    entities=path_entities,
                    root_node_id=eid,
                )
                _merge(p_nodes, p_edges)

        # Lateral movement paths
        lm_spec = spec.get("lateralMovement") or {}
        lm_field = lm_spec.get("field", "lateralMovementPaths")
        lm_nodes_field = lm_spec.get("nodesField", "nodes")
        lm_path_entities_field = lm_spec.get("pathEntitiesField", "pathEntities")
        lm_entity_field = lm_spec.get("pathEntityEntityField", "entity")
        lm_missing = lm_spec.get("missingEntityStrategy", "DELETED_RESOURCE_MOCK")
        lm_obj = entity.get(lm_field)
        lm_nodes = lm_obj.get(lm_nodes_field) if isinstance(lm_obj, dict) else None
        if isinstance(lm_nodes, list):
            for lm in lm_nodes:
                if not isinstance(lm, dict):
                    continue
                path_entities_wrapped = lm.get(lm_path_entities_field) or []
                if not isinstance(path_entities_wrapped, list):
                    path_entities_wrapped = []
                entities_list: List[Dict[str, Any]] = []
                lm_path_id = str(lm.get("id") or lm_field)
                for pe_idx, pe in enumerate(path_entities_wrapped):
                    if not isinstance(pe, dict):
                        continue
                    ent = pe.get(lm_entity_field)
                    if isinstance(ent, dict):
                        entities_list.append(ent)
                    else:
                        if lm_missing == "DELETED_RESOURCE_MOCK":
                            entities_list.append(_deleted_resource_mock_entity(lm_path_id, pe_idx))
                p_nodes, p_edges = _calc_items_from_path(
                    path_id=lm_path_id,
                    entities=entities_list,
                    root_node_id=None,
                )
                _merge(p_nodes, p_edges)

        # Kubernetes paths
        k8s_spec = spec.get("kubernetes") or {}
        k8s_field = k8s_spec.get("field", "kubernetesPaths")
        k8s_nodes_field = k8s_spec.get("nodesField", "nodes")
        k8s_path_field = k8s_spec.get("pathField", "path")
        k8s_obj = entity.get(k8s_field)
        k8s_nodes = k8s_obj.get(k8s_nodes_field) if isinstance(k8s_obj, dict) else None
        if isinstance(k8s_nodes, list):
            for k8s in k8s_nodes:
                if not isinstance(k8s, dict):
                    continue
                path_entities = k8s.get(k8s_path_field) or []
                if not isinstance(path_entities, list):
                    continue
                p_nodes, p_edges = _calc_items_from_path(
                    path_id=str(k8s.get("id") or k8s_field),
                    entities=path_entities,
                    root_node_id=None,
                )
                _merge(p_nodes, p_edges)

        # Extra misc paths
        misc_n, misc_e = _extra_misc_paths(
            entity=entity,
            public_exposure_endpoint_ids=public_exposure_endpoint_ids,
        )
        _merge(misc_n, misc_e)

    # Also add misc paths for every entity seen in path nodes
    for node in list(nodes_by_id.values()):
        if not isinstance(node, dict):
            continue
        if node.get("id") == SECURITY_GRAPH_INTERNET_NODE_ID:
            continue
        if node.get("type") in ("INTERNET",):
            continue
        misc_n, misc_e = _extra_misc_paths(
            entity=node,
            public_exposure_endpoint_ids=public_exposure_endpoint_ids,
        )
        _merge(misc_n, misc_e)

    # Create edges based on the evidence query structure
    if evidence_query and isinstance(evidence_query, dict):
        query_map = _calc_graph_query_map(evidence_query)
        for record in graph_search_nodes or []:
            if isinstance(record, dict):
                _create_edges_from_query_map(query_map, record, nodes_by_id, edges_by_id)

    # Remove Internet node if it's not connected to any edges
    internet_has_edges = any(
        e.get("from") == internet_node_id or e.get("to") == internet_node_id
        for e in edges_by_id.values()
    )
    if not internet_has_edges and internet_node_id in nodes_by_id:
        del nodes_by_id[internet_node_id]

    # Build simplified output
    nodes_list = sorted(nodes_by_id.values(), key=lambda x: str(x.get("id") or ""))

    # Simplify edges to just from/to
    edges_list = sorted(
        [{"from": e.get("from"), "to": e.get("to")} for e in edges_by_id.values()],
        key=lambda x: f"{x.get('from')}->{x.get('to')}"
    )

    return {
        "nodes": nodes_list,
        "edges": edges_list,
        "_metadata": {
            "nodeCount": len(nodes_list),
            "edgeCount": len(edges_list),
        },
    }


async def get_issue_attack_path_structure(
    *,
    issue_id: str,
    project_id: str = "*",
    first: int = 100,
    after: Optional[str] = None,
    quick: bool = True,
    fetch_public_exposure_paths: bool = True,
    fetch_internal_exposure_paths: bool = False,
    fetch_lateral_movement: bool = True,
    fetch_code_source: bool = False,
    fetch_kubernetes: bool = True,
    is_network_path_expanded: bool = False,
    fetch_total_count: bool = False,
    ctx_original_prompt: Optional[str] = None,
    ctx_model_id: Optional[str] = None,
    ctx_execution_environment: Optional[str] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Get the attack path visualization for a Wiz Issue.

    Returns nodes and edges representing the Wiz Security Graph structure.
    Supports various path layers: public exposure, lateral movement, kubernetes, etc.
    """
    context_params = {
        "ctx_original_prompt": ctx_original_prompt,
        "ctx_model_id": ctx_model_id,
        "ctx_execution_environment": ctx_execution_environment,
    }

    wiz_ctx = ctx.request_context.lifespan_context

    graphql_query = """
query GraphSearch(
  $query: GraphEntityQueryInput
  $projectId: String!
  $first: Int
  $after: String
  $fetchTotalCount: Boolean = false
  $quick: Boolean = true
  $fetchPublicExposurePaths: Boolean = false
  $fetchInternalExposurePaths: Boolean = false
  $fetchLateralMovement: Boolean = false
  $fetchCodeSource: Boolean = false
  $fetchKubernetes: Boolean = false
  $issueId: ID
) {
  graphSearch(
    query: $query
    projectId: $projectId
    first: $first
    after: $after
    quick: $quick
    issueId: $issueId
  ) {
    totalCount @include(if: $fetchTotalCount)
    maxCountReached @include(if: $fetchTotalCount)
    pageInfo {
      endCursor
      hasNextPage
    }
    nodes {
      entities {
        id
        name
        type
        properties
        publicExposures(first: 100) @include(if: $fetchPublicExposurePaths) {
          nodes {
            id
            path { id name type }
            applicationEndpoints { id name type }
          }
        }
        otherSubscriptionExposures(first: 100) @include(if: $fetchInternalExposurePaths) {
          nodes {
            id
            path { id name type }
          }
        }
        otherVnetExposures(first: 100) @include(if: $fetchInternalExposurePaths) {
          nodes {
            id
            path { id name type }
          }
        }
        lateralMovementPaths(first: 100) @include(if: $fetchLateralMovement) {
          nodes {
            id
            pathEntities {
              entity { id name type }
            }
          }
        }
        codeSourcePath(first: 100) @include(if: $fetchCodeSource) {
          nodes {
            id
            pathEntities { id name type }
          }
        }
        kubernetesPaths(first: 100) @include(if: $fetchKubernetes) {
          nodes {
            id
            path { id name type }
          }
        }
      }
    }
  }
}
"""

    if first is None:
        first = 100

    variables = {
        "projectId": project_id,
        "issueId": issue_id,
        "first": first,
        "after": after,
        "quick": bool(quick),
        "fetchTotalCount": bool(fetch_total_count),
        "fetchPublicExposurePaths": bool(fetch_public_exposure_paths),
        "fetchInternalExposurePaths": bool(fetch_internal_exposure_paths),
        "fetchLateralMovement": bool(fetch_lateral_movement),
        "fetchCodeSource": bool(fetch_code_source),
        "fetchKubernetes": bool(fetch_kubernetes),
        "query": None,
    }

    result = await execute_graphql_query(
        query=graphql_query,
        variables=variables,
        auth_headers=wiz_ctx.auth_headers,
        dc=wiz_ctx.data_center,
        env=wiz_ctx.env,
        context_params=context_params,
    )

    if isinstance(result, dict) and "error" in result:
        return result
    if isinstance(result, dict) and "errors" in result:
        return {"error": "GraphQL query failed", "details": result.get("errors")}

    data = result.get("data") if isinstance(result, dict) else None
    graph_search = data.get("graphSearch") if isinstance(data, dict) else None
    if not isinstance(graph_search, dict):
        return {"error": "GraphQL response missing graphSearch", "response": result}

    nodes = graph_search.get("nodes") or []

    # Fetch the issue's evidence query
    evidence_query = await fetch_issue_evidence_query(
        issue_id=issue_id,
        auth_headers=wiz_ctx.auth_headers,
        dc=wiz_ctx.data_center,
        env=wiz_ctx.env,
        context_params=context_params,
    )

    items_payload = _build_attack_path_items(
        graph_search_nodes=nodes,
        is_network_path_expanded=bool(is_network_path_expanded),
        evidence_query=evidence_query,
    )

    return items_payload


def register_issue_attack_path_structure_tool(mcp: FastMCP) -> None:
    """Register the get_issue_attack_path_structure tool with the FastMCP server."""
    @mcp.tool(
        name="get_issue_attack_path_structure",
        description=(
            "Get the attack path visualization for an issue. "
            "Returns nodes and edges representing the attack path structure. "
            "Supports various path layers: public exposure, lateral movement, kubernetes, etc."
        ),
    )
    async def get_issue_attack_path_structure_tool(
        issue_id: str,
        project_id: str = "*",
        first: int = 100,
        quick: bool = True,
        fetch_public_exposure_paths: bool = True,
        fetch_internal_exposure_paths: bool = False,
        fetch_lateral_movement: bool = True,
        fetch_code_source: bool = False,
        fetch_kubernetes: bool = True,
        is_network_path_expanded: bool = False,
        fetch_total_count: bool = False,
        ctx_original_prompt: Optional[str] = None,
        ctx_model_id: Optional[str] = None,
        ctx_execution_environment: Optional[str] = None,
        ctx: Context = None,
    ) -> Dict[str, Any]:
        try:
            result = await get_issue_attack_path_structure(
                issue_id=issue_id,
                project_id=project_id,
                first=first,
                quick=quick,
                fetch_public_exposure_paths=fetch_public_exposure_paths,
                fetch_internal_exposure_paths=fetch_internal_exposure_paths,
                fetch_lateral_movement=fetch_lateral_movement,
                fetch_code_source=fetch_code_source,
                fetch_kubernetes=fetch_kubernetes,
                is_network_path_expanded=is_network_path_expanded,
                fetch_total_count=fetch_total_count,
                ctx_original_prompt=ctx_original_prompt,
                ctx_model_id=ctx_model_id,
                ctx_execution_environment=ctx_execution_environment,
                ctx=ctx,
            )
            if result is None:
                return {
                    "error": "tool_exception",
                    "tool": "get_issue_attack_path_structure",
                    "issue_id": issue_id,
                    "project_id": project_id,
                    "exception_type": "NoneResult",
                    "message": "Tool returned no result (None).",
                    "traceback": None,
                    "action": "Report this as a Wiz MCP tool exception with the payload above.",
                }
            return result
        except BaseException as e:
            tb = traceback.format_exc()
            if len(tb) > 8000:
                tb = tb[-8000:]
            return {
                "error": "tool_exception",
                "tool": "get_issue_attack_path_structure",
                "issue_id": issue_id,
                "project_id": project_id,
                "exception_type": type(e).__name__,
                "message": str(e),
                "traceback": tb,
                "action": "Report this as a Wiz MCP tool exception with the payload above.",
            }

    logger.info("Registered get_issue_attack_path_structure tool")
