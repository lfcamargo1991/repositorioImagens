"""
Remote WIN API Specs Loader.

This module provides functionality to load WIN API specifications from remote sources.
Reuses zip download/cache logic from RemoteToolDefinitionLoader.
"""

import io
import os
import tempfile
import zipfile
import shutil
from typing import Optional

from wiz_mcp_server.utils.logger import get_logger
from wiz_mcp_server.utils.user_agent import is_win_only_mode
from .remote_tool_definition_loader import RemoteToolDefinitionLoader

logger = get_logger()


class RemoteWinApiSpecsLoader:
    """Loader for WIN API specifications from remote sources (e.g., ZIP files, URLs)."""

    def _get_zip_content(self, source_location: str) -> Optional[bytes]:
        """
        Get the zip content from cache or download it if needed.
        Reuses the logic from RemoteToolDefinitionLoader.

        Args:
            source_location: URL to download from

        Returns:
            Zip content as bytes or None if download failed
        """
        # Reuse the zip download/cache logic from RemoteToolDefinitionLoader
        loader = RemoteToolDefinitionLoader()
        zip_content = loader._get_zip_content(source_location)
        if zip_content:
            logger.info("Retrieved WIN API specs zip content")
        return zip_content

    def load_api_specs(self, source_location: str) -> bool:
        """
        Load WIN API specifications from a remote source location.

        Extracts win-content/api-specs from the zip and sets WIZ_WIN_CONTENT_PATH.

        Args:
            source_location: Remote location containing WIN API specs (e.g., ZIP URL)

        Returns:
            bool: True if successfully loaded and WIZ_WIN_CONTENT_PATH was set, False otherwise
        """
        try:
            # Get the zip content (from cache or download)
            zip_content = self._get_zip_content(source_location)
            if not zip_content:
                logger.error("Failed to get zip content, cannot load WIN API specs")
                return False

            # Create a temporary directory to extract files
            with tempfile.TemporaryDirectory() as temp_dir:
                # Extract the ZIP file
                with zipfile.ZipFile(io.BytesIO(zip_content)) as zip_ref:
                    zip_ref.extractall(temp_dir)

                    # Find the win-content directory in the extracted ZIP
                    win_content_dir = None

                    # Search for win-content/api-specs
                    for root, dirs, _ in os.walk(temp_dir):
                        base = os.path.basename(root)
                        if base == 'win-content' and win_content_dir is None:
                            # Prefer nested api-specs under win-content
                            api_specs = os.path.join(root, 'api-specs')
                            if os.path.isdir(api_specs):
                                win_content_dir = root
                                break

                    if not win_content_dir:
                        logger.error("Could not find win-content/api-specs directory in the ZIP file")
                        return False

                    # Copy win-content to a persistent cache dir and set env var
                    try:
                        cache_dir = os.path.join(tempfile.gettempdir(), 'wiz_mcp_win_api_specs')
                        # Replace the cache directory atomically
                        if os.path.exists(cache_dir):
                            shutil.rmtree(cache_dir, ignore_errors=True)
                        shutil.copytree(win_content_dir, cache_dir)
                        # Set the correct environment variable based on mode
                        is_win_only = is_win_only_mode()
                        if is_win_only:
                            env_var_name = 'WIN_CONTENT_PATH'
                        else:
                            env_var_name = 'WIZ_WIN_CONTENT_PATH'
                        os.environ[env_var_name] = cache_dir
                        logger.info(f"WIN API specs available; set {env_var_name} to {cache_dir}")
                        return True
                    except Exception as e:
                        logger.warning(f"Failed to prepare WIN API specs cache: {e}")
                        return False
        except Exception as e:
            logger.error(f"Error loading WIN API specs from {source_location}: {e}")
            return False

    @classmethod
    def clear_cache(cls, source_location: Optional[str] = None) -> None:
        """
        Clear the zip content cache.
        Reuses the cache from RemoteToolDefinitionLoader.

        Args:
            source_location: Optional URL to clear from cache. If None, clears the entire cache.
        """
        # Reuse the cache clearing from RemoteToolDefinitionLoader
        RemoteToolDefinitionLoader.clear_cache(source_location)
