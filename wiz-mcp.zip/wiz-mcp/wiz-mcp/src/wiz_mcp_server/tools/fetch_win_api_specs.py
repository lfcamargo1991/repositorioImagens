"""
WIN API Specs Fetching for the Wiz MCP Server.

This module provides functionality to fetch WIN API specifications from remote sources.
"""

import os
from typing import Tuple, Optional

from wiz_mcp_server.utils.logger import get_logger
from wiz_mcp_server.utils.user_agent import is_win_only_mode
from .remote_win_api_specs_loader import RemoteWinApiSpecsLoader
from .crypto_utils import decrypt

logger = get_logger()

# Encrypted URLs for WIN API specs - manually encrypted and added to code
_DEFAULT_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_TID = "Z0FBQUFBQnBMYndqc291LWQ3QVZtb2QwNS1rQ0x1X09yRmM5TWtva2FEblMwTnVGbG5SRE51WjNvNksyRlhfRGYtRWJjaERFWnczZzB3NlBCOGljX2E1am9uQ1NlX25MaEdhaGxWV0tVMnNPZFIxcjR2NC1xVk9EbVBEdGJmYW5abnVUTFBTQzluaU1yekliLUNROXFGTlR0MXJWd29JUnBMT3ZBeFFiOVR2QUs4TktTWjJGWS1JPQ=="  # noqa: E501
_DEFAULT_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_AFFILIATION = "Z0FBQUFBQnBMYm9hUVdCdUZ6XzFDUFpYWnAzMDB5ZWpXZl9oLWYzVWx1UzJ6bEZNYkRFdzhja3JmbjdRR2NnSFFKSkt2R3gzZW5CaHY3dkt4cTVWUDk4cHZRNW1vTDB3UUZrYjZleDM2U3NhREQwQUVnT2VRZzByTFQyZjJwcjhqSElwV3RkdVAzQVFJTDVUa1BIRDktOS1sdXlqOUlGdG5MYjM5REpsNkVHZFR5aEU4Z1Z3b3djPQ=="  # noqa: E501


def get_encrypted_win_api_specs_url() -> Tuple[Optional[str], Optional[str]]:
    """
    Get the encrypted WIN API specs URL based on mode and environment.

    Returns:
        tuple: (encrypted_url, key_env_var_name) or (None, None) if not available
    """
    is_win_only = is_win_only_mode()

    if is_win_only:
        # WIN-only mode: use tid-based encrypted URL
        encrypted_url = os.environ.get("WIZ_MCP_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_TID")
        if encrypted_url is None:
            encrypted_url = _DEFAULT_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_TID
        key_env_var = "WIZ_MCP_WIN_API_SPECS_KEY_TID"
    else:
        # Full mode: use affiliation_id-based encrypted URL
        encrypted_url = os.environ.get("WIZ_MCP_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_AFFILIATION")
        if encrypted_url is None:
            encrypted_url = _DEFAULT_ENCRYPTED_REMOTE_WIN_API_SPECS_URL_AFFILIATION
        key_env_var = "WIZ_MCP_WIN_API_SPECS_KEY_AFFILIATION"

    if not encrypted_url:
        return (None, None)

    return (encrypted_url, key_env_var)


def fetch_win_api_specs() -> bool:
    """
    Fetch WIN API specifications from remote source.

    This function downloads and extracts WIN API specs, setting WIZ_WIN_CONTENT_PATH
    if successful.

    Returns:
        bool: True if successfully fetched and WIZ_WIN_CONTENT_PATH was set, False otherwise
    """
    # Check if remote WIN API specs are disabled
    remote_specs_disabled = os.environ.get("WIZ_MCP_REMOTE_WIN_API_SPECS_DISABLED", "false").lower()
    remote_specs_enabled = remote_specs_disabled not in ("true", "1", "yes", "y", "on")

    if not remote_specs_enabled:
        logger.info("Remote WIN API specs are disabled")
        return False

    # Get the encrypted URL and key env var name based on mode
    encrypted_url, key_env_var = get_encrypted_win_api_specs_url()

    if not encrypted_url:
        logger.debug("No encrypted WIN API specs URL available")
        return False

    # Get the decryption key from environment (set during authentication)
    decryption_key = os.environ.get(key_env_var, "")

    if not decryption_key:
        logger.debug(f"Remote WIN API specs URL available but no decryption key ({key_env_var}) is available")
        return False

    # Decrypt the URL
    try:
        # Try Fernet first (recommended), fall back to XOR if needed
        remote_specs_url = decrypt(encrypted_url, decryption_key, use_fernet=True)
        logger.info("Successfully decrypted WIN API specs URL using organization credentials")
    except Exception as e:
        logger.warning(f"Failed to decrypt WIN API specs URL: {e}")
        return False

    # Load WIN API specs from remote source
    try:
        logger.info("Attempting to load WIN API specs from remote source")
        loader = RemoteWinApiSpecsLoader()
        success = loader.load_api_specs(remote_specs_url)
        if success:
            logger.info("Successfully loaded WIN API specs from remote source")
            return True
        else:
            logger.warning("Failed to load WIN API specs from remote source")
            return False
    except Exception as e:
        logger.warning(f"Failed to load WIN API specs from remote source: {e}")
        return False
