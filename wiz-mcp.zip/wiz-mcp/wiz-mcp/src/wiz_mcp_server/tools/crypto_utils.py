"""
Cryptography utilities for Wiz MCP Server.

This module provides encryption/decryption functions for URLs and other sensitive data.
Supports both XOR (legacy) and Fernet (recommended) encryption methods.
"""

import base64

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.backends import default_backend
    FERNET_AVAILABLE = True
except ImportError:
    FERNET_AVAILABLE = False

from wiz_mcp_server.utils.logger import get_logger

logger = get_logger()


def decrypt_xor(encrypted_b64: str, key: str) -> str:
    """
    Decrypt a base64-encoded string using XOR with the provided key (legacy method).

    Args:
        encrypted_b64: Base64-encoded encrypted string
        key: Decryption key

    Returns:
        str: Decrypted string
    """
    key_bytes = key.encode()
    encrypted = base64.b64decode(encrypted_b64)
    decrypted = bytes([b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(encrypted)])
    return decrypted.decode()


def derive_key_from_uuid(uuid_str: str) -> bytes:
    """
    Derive a 32-byte key from UUID using PBKDF2.

    Args:
        uuid_str: UUID string (tid or affiliation_id)

    Returns:
        32-byte key suitable for Fernet
    """
    if not FERNET_AVAILABLE:
        raise ImportError(
            "cryptography library is required for Fernet encryption. "
            "Install it with: pip install cryptography"
        )

    # Use UUID as salt for deterministic key derivation
    # This ensures same UUID always produces same key
    salt = uuid_str.encode()

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,  # Standard secure iteration count
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(uuid_str.encode()))
    return key


def decrypt_fernet(encrypted_b64: str, uuid_key: str) -> str:
    """
    Decrypt a URL using Fernet with a key derived from UUID.

    Args:
        encrypted_b64: Base64-encoded encrypted URL
        uuid_key: UUID string (tid or affiliation_id) used for decryption

    Returns:
        Decrypted URL string

    Raises:
        ImportError: If cryptography library is not available
        cryptography.fernet.InvalidToken: If decryption fails (wrong key or tampered data)
    """
    if not FERNET_AVAILABLE:
        raise ImportError(
            "cryptography library is required for Fernet encryption. "
            "Install it with: pip install cryptography"
        )

    key = derive_key_from_uuid(uuid_key)
    fernet = Fernet(key)
    encrypted = base64.b64decode(encrypted_b64)
    decrypted = fernet.decrypt(encrypted)
    return decrypted.decode()


def decrypt(encrypted_b64: str, key: str, use_fernet: bool = True) -> str:
    """
    Decrypt a base64-encoded string, trying Fernet first, falling back to XOR.

    Args:
        encrypted_b64: Base64-encoded encrypted string
        key: Decryption key (UUID string for Fernet, any string for XOR)
        use_fernet: If True, try Fernet first; if False, use XOR only

    Returns:
        str: Decrypted string

    Raises:
        ValueError: If decryption fails with both methods
    """
    # Try Fernet first if available and requested
    if use_fernet and FERNET_AVAILABLE:
        try:
            return decrypt_fernet(encrypted_b64, key)
        except Exception as e:
            logger.debug(f"Fernet decryption failed, trying XOR: {e}")
            # Fall through to XOR

    # Fall back to XOR (legacy method)
    try:
        return decrypt_xor(encrypted_b64, key)
    except Exception as e:
        logger.error(f"XOR decryption also failed: {e}")
        raise ValueError(f"Failed to decrypt with both Fernet and XOR methods: {e}")
