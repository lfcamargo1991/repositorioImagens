"""
User-Agent utility for Wiz MCP Server.

This module provides functionality to generate consistent User-Agent strings
across all HTTP requests (authentication and GraphQL).
"""

import os
import pathlib

from wiz_mcp_server.version import __version__


def is_win_only_mode() -> bool:
    """
    Check if we're in WIN-only mode by checking env var or marker file.

    Returns:
        bool: True if in WIN-only mode, False otherwise
    """
    # First check environment variable
    mcp_mode = os.environ.get("WIZ_MCP_MODE")
    if mcp_mode:
        if mcp_mode.lower() == "win-only":
            return True
        # If set to something else, return False (not WIN-only mode)
        return False

    # If not set, check for .win-only marker file
    try:
        # Get package root (src/wiz_mcp_server/utils -> src/wiz_mcp_server -> src -> root)
        current_file = pathlib.Path(__file__).resolve()
        package_root = current_file.parent.parent.parent.parent

        # Check multiple possible locations for the marker file
        # 1. Calculated package root (standard case)
        # 2. Current working directory (when running from extracted zip)
        # 3. Parent of package root if package root is named 'win-mcp' or 'wiz-mcp' (zip extraction scenario)
        possible_roots = [package_root]

        # Add CWD if different from package root
        cwd = pathlib.Path(os.getcwd())
        if cwd != package_root:
            possible_roots.append(cwd)

        # If package root is 'win-mcp' or 'wiz-mcp', also check parent
        if package_root.name in ('win-mcp', 'wiz-mcp') and package_root.parent.exists():
            possible_roots.append(package_root.parent)

        # Check all possible locations
        for root in possible_roots:
            if root and root.exists():
                marker = root / ".win-only"
                if marker.exists():
                    return True

        return False
    except Exception:
        # If we can't determine, default to False
        return False


def get_tools_source() -> str:
    """
    Get the tools source identifier for User-Agent.

    Returns:
        str: "win" for WIN-only mode, "remote" for remote tools, "local" for local tools
    """
    # Check if we're in WIN-only mode
    if is_win_only_mode():
        return "win"

    # Check if tools were loaded from remote source
    return "remote" if os.environ.get("WIZ_MCP_USING_REMOTE_TOOLS", "").lower() == "true" else "local"


def get_user_agent() -> str:
    """
    Get the User-Agent string for HTTP requests.

    Returns:
        str: User-Agent string in format "Wiz-MCP-Server/{version}/{tools_source}"
    """
    tools_source = get_tools_source()
    return f"Wiz-MCP-Server/{__version__}/{tools_source}"
