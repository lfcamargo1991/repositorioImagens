#!/usr/bin/env python3
"""
Test script for get_issue_attack_path_structure tool.
Tests with the issue ID we've been working with.
"""

import asyncio
import json
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Import after path setup
from wiz_mcp_server.tools.issue_attack_path_structure_tool import (  # noqa: E402
    get_issue_attack_path_structure
)
from wiz_mcp_server.auth.auth import authenticate  # noqa: E402
from wiz_mcp_server.utils.context import WizContext  # noqa: E402
from wiz_mcp_server.utils.logger import get_logger  # noqa: E402

logger = get_logger()


class MockContext:
    """Mock MCP context for testing"""
    class RequestContext:
        def __init__(self, lifespan_context):
            self.lifespan_context = lifespan_context

    def __init__(self, wiz_ctx):
        self.request_context = self.RequestContext(wiz_ctx)


async def test_attack_path_tool():
    """Test the attack path tool with the issue ID"""
    issue_id = "e99a42fc-1b48-4d9e-bebb-7770338554dc"
    project_id = "*"

    print(f"\n{'='*80}")
    print("Testing get_issue_attack_path_structure")
    print(f"Issue ID: {issue_id}")
    print(f"Project ID: {project_id}")
    print(f"{'='*80}\n")

    try:
        # Authenticate with Wiz API (extracts DC from JWT)
        logger.info("Authenticating with Wiz API...")
        auth_result = await authenticate()
        wiz_ctx = WizContext(
            auth_headers=auth_result.auth_headers,
            data_center=auth_result.data_center,
            env=auth_result.env
        )
        logger.info(f"Authenticated successfully (DC: {wiz_ctx.data_center}, Env: {wiz_ctx.env})")

        # Create mock context with authenticated Wiz context
        ctx = MockContext(wiz_ctx)

        # Call the function with the same parameters as the UI
        result = await get_issue_attack_path_structure(
            issue_id=issue_id,
            project_id=project_id,
            first=50,  # UI page size
            fetch_lateral_movement=True,  # lateral_movement layer
            fetch_kubernetes=True,  # kubernetes layer
            fetch_code_source=False,
            fetch_public_exposure=False,
            fetch_internal_exposure=False,
            fetch_network_connections=False,  # Not in URL layers
            ctx=ctx
        )

        # Check if we got an error
        if "error" in result:
            print(f"❌ ERROR: {result.get('error')}")
            if "details" in result:
                print(f"Details: {json.dumps(result.get('details'), indent=2)}")
            return False

        # Analyze the result
        nodes = result.get("nodes", [])
        edges = result.get("edges", [])
        metadata = result.get("_metadata", {})

        print("✅ SUCCESS!")
        print("\nResults:")
        print(f"  - Nodes: {len(nodes)}")
        print(f"  - Edges: {len(edges)}")

        if metadata:
            print("\nMetadata:")
            for key, value in metadata.items():
                print(f"  - {key}: {value}")

        # Show node types breakdown
        node_types = {}
        for node in nodes:
            node_type = node.get("type", "UNKNOWN")
            node_types[node_type] = node_types.get(node_type, 0) + 1

        print("\nNode Types Breakdown:")
        for node_type, count in sorted(node_types.items()):
            print(f"  - {node_type}: {count}")

        # Show all nodes with their names
        print("\nAll Nodes (sorted by type, then name):")
        nodes_by_type = {}
        for node in nodes:
            node_type = node.get("type", "UNKNOWN")
            if node_type not in nodes_by_type:
                nodes_by_type[node_type] = []
            nodes_by_type[node_type].append(node)

        for node_type in sorted(nodes_by_type.keys()):
            print(f"\n  {node_type}:")
            for node in sorted(nodes_by_type[node_type], key=lambda n: n.get("name", "")):
                node_name = node.get("name", "NO_NAME")
                node_id = node.get("id", "NO_ID")[:30]
                print(f"    - {node_name} (id: {node_id}...)")

        # Also show sample for quick reference
        print("\nSample Nodes (first 10):")
        for i, node in enumerate(nodes[:10]):
            print(f"  {i+1}. {node.get('type')} - {node.get('name')} (id: {node.get('id')[:20]}...)")

        # Show sample edges
        print("\nSample Edges (first 10):")
        for i, edge in enumerate(edges[:10]):
            from_id = edge.get("from", "")[:20]
            to_id = edge.get("to", "")[:20]
            print(f"  {i+1}. {from_id}... -> {to_id}...")

        # Validate structure
        print("\nValidation:")
        issues = []

        if len(nodes) == 0:
            issues.append("❌ No nodes found - this might indicate a problem")
        else:
            print(f"  ✅ Found {len(nodes)} nodes")

        if len(edges) == 0:
            issues.append("❌ No edges found - this might indicate a problem")
        else:
            print(f"  ✅ Found {len(edges)} edges")

        # Check for KUBERNETES_CLUSTER node (any cluster, not a specific one)
        cluster_found = any(node.get("type") == "KUBERNETES_CLUSTER" for node in nodes)
        if cluster_found:
            cluster_nodes = [n for n in nodes if n.get("type") == "KUBERNETES_CLUSTER"]
            print(f"  ✅ Found {len(cluster_nodes)} KUBERNETES_CLUSTER node(s)")
        else:
            issues.append(
                "  ⚠️  No KUBERNETES_CLUSTER node found "
                "(might be expected for non-K8s issues)"
            )

        # Check node IDs are unique
        node_ids = [node.get("id") for node in nodes if node.get("id")]
        unique_node_ids = set(node_ids)
        if len(node_ids) == len(unique_node_ids):
            print("  ✅ All node IDs are unique")
        else:
            issues.append(f"  ❌ Duplicate node IDs found: {len(node_ids) - len(unique_node_ids)} duplicates")

        # Check edge structure
        edge_from_ids = {edge.get("from") for edge in edges if edge.get("from")}
        edge_to_ids = {edge.get("to") for edge in edges if edge.get("to")}
        all_edge_node_ids = edge_from_ids | edge_to_ids

        # Check if all edge node IDs exist in nodes
        node_id_set = set(node_ids)
        missing_edge_nodes = all_edge_node_ids - node_id_set
        if not missing_edge_nodes:
            print("  ✅ All edge node IDs exist in nodes")
        else:
            issues.append(f"  ❌ {len(missing_edge_nodes)} edge node IDs don't exist in nodes")

        if issues:
            print("\n⚠️  Issues found:")
            for issue in issues:
                print(f"  {issue}")
            return False
        else:
            print("\n✅ All validations passed!")
            return True

    except Exception as e:
        print(f"\n❌ EXCEPTION: {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    # Load environment variables from .env file
    # Use the same path as mcp.json WIZ_DOTENV_PATH
    try:
        from dotenv import load_dotenv

        # Default path from mcp.json
        default_env_path = "/Users/hen.perez/wiz-drive/OneDrive - Wiz/playground/wiz-sec/wiz-mcp/src/wiz_mcp_server/.env"

        # Try to load from WIZ_DOTENV_PATH env var first, then default path, then common locations
        env_paths = [
            os.environ.get("WIZ_DOTENV_PATH"),
            default_env_path,
            os.path.join(os.getcwd(), ".env"),
            os.path.join(os.path.dirname(__file__), ".env"),
            os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"),
        ]

        env_loaded = False
        for path in env_paths:
            if path and os.path.exists(path):
                load_dotenv(path)
                logger.info(f"Loaded environment from {path}")
                env_loaded = True
                break

        if not env_loaded:
            logger.warning("No .env file found in expected locations")
    except ImportError:
        logger.warning("python-dotenv not installed, skipping .env file loading")

    print("Note: This test requires valid Wiz authentication.")
    print("Make sure you have WIZ_CLIENT_ID, WIZ_CLIENT_SECRET, and WIZ_ENV set.")
    print()

    success = asyncio.run(test_attack_path_tool())
    sys.exit(0 if success else 1)
